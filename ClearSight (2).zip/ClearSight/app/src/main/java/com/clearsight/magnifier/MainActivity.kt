package com.clearsight.magnifier

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var overlayStatus: TextView
    private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }
    private val zooms = listOf(1.5f, 2.0f, 2.5f, 3.0f)
    private val sizes = listOf(160, 220, 280) // dp width: Small, Medium, Large
    private val bg = 0xFF0E0F13.toInt()
    private val cardColor = 0xFF171922.toInt()
    private val accent = 0xFF3D7BFF.toInt()
    private val muted = 0xFF8E94A3.toInt()
    private val soft = 0xFFB8BECC.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg; window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_logo) }, LinearLayout.LayoutParams(dp(60), dp(60)))
        header.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0)
            addView(label("ClearSight", 26f, Color.WHITE, true))
            addView(label("Magnifier para sa malinaw na pagtingin", 13f, muted, false))
        })
        root.addView(header)

        overlayStatus = label("", 14f, Color.WHITE, false).apply { setPadding(0, dp(8), 0, 0) }
        root.addView(cardOf(
            label("STATUS", 11f, muted, true), overlayStatus,
            label("● Screen capture: hihingin tuwing Start", 14f, soft, false).apply { setPadding(0, dp(4), 0, 0) }
        ))

        val zi = zooms.indexOf(prefs.getFloat("zoom", 2f)).coerceAtLeast(0)
        val si = sizes.indexOf(prefs.getInt("size", 220)).coerceAtLeast(0)
        val sharpIdx = if (prefs.getBoolean("sharp", true)) 0 else 1
        root.addView(cardOf(
            sectionLabel("Magnification"),
            chips(zooms.map { "${it}x" }, zi) { prefs.edit().putFloat("zoom", zooms[it]).apply() },
            sectionLabel("Lens size"),
            chips(listOf("Small", "Medium", "Large"), si) { prefs.edit().putInt("size", sizes[it]).apply() },
            sectionLabel("Sharpen (Android 13+)"),
            chips(listOf("On", "Off"), sharpIdx) { prefs.edit().putBoolean("sharp", it == 0).apply() }
        ))

        root.addView(Button(this).apply {
            text = "Start Magnifier"; isAllCaps = false; textSize = 17f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = round(accent, 14); setOnClickListener { start() }
        }, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(18) })

        root.addView(cardOf(
            label("PRIVACY", 11f, muted, true),
            label(
                "✓ Offline: walang INTERNET permission\n✓ Walang ads, account, o data collection\n✓ Nasa memory lang ang screen frames; hindi sine-save",
                13f, soft, false
            ).apply { setPadding(0, dp(8), 0, 0); setLineSpacing(0f, 1.25f) }
        ))
        root.addView(label(
            "Tip: sa screen-share prompt, piliin ang \"Entire screen\". Ang asul na kahon ang area na pinalalaki. Long-press ang lens para sa controls.   v1.1",
            12f, 0xFF6B7180.toInt(), false
        ).apply { setPadding(0, dp(16), 0, 0) })

        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val ok = Settings.canDrawOverlays(this)
        overlayStatus.text = if (ok) "● Overlay permission: Granted" else "● Overlay permission: Kailangan"
        overlayStatus.setTextColor(if (ok) 0xFF4ADE80.toInt() else 0xFFFBBF24.toInt())
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, MagnifierService::class.java)
                    .putExtra(MagnifierService.EXTRA_CODE, res)
                    .putExtra(MagnifierService.EXTRA_DATA, data)
            )
            moveTaskToBack(true)
        }
    }

    private fun round(color: Int, r: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r).toFloat() }

    private fun label(t: String, sp: Float, c: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c)
        typeface = Typeface.create(if (bold) "sans-serif-medium" else "sans-serif", Typeface.NORMAL)
        if (bold && sp < 14f) letterSpacing = 0.1f
    }

    private fun sectionLabel(t: String) = label(t, 13f, muted, false).apply { setPadding(0, dp(12), 0, dp(8)) }

    private fun cardOf(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = round(cardColor, 16)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        views.forEach { addView(it) }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
    }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = labels.map { Button(this).apply { text = it; isAllCaps = false; setTextColor(Color.WHITE) } }
        fun paint(sel: Int) = buttons.forEachIndexed { i, bt ->
            bt.background = round(if (i == sel) accent else 0xFF242836.toInt(), 12)
        }
        buttons.forEachIndexed { i, bt ->
            bt.setOnClickListener { paint(i); onPick(i) }
            row.addView(bt, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        paint(selected)
        return row
    }
}

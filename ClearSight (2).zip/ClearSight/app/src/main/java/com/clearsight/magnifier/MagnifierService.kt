package com.clearsight.magnifier

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executor

class MagnifierService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        const val ASPECT = 0.6f // lens height = width * ASPECT (rectangle)
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var capHandler: Handler? = null
    private var lastImage: Image? = null // only touched on capture thread
    private var bmp: Bitmap? = null      // only touched on capture thread
    private var lens: LensView? = null
    private var panel: View? = null
    private var dot: View? = null
    private var srcFrame: View? = null
    private lateinit var srcFrameLp: WindowManager.LayoutParams
    @Volatile private var minIntervalMs = 8L
    private var thermalListener: PowerManager.OnThermalStatusChangedListener? = null
    private var zoomLabel: TextView? = null
    private lateinit var lensLp: WindowManager.LayoutParams
    private var panelShown = false
    private var screenW = 0; private var screenH = 0; private var dpi = 0
    @Volatile private var lastFrame = 0L
    @Volatile private var zoom = 2f
    @Volatile private var sizePx = 0
    @Volatile private var posX = 0
    @Volatile private var posY = 0
    @Volatile private var lensShown = true
    private val zooms = listOf(1.5f, 2.0f, 2.5f, 3.0f)
    private val renderRun = Runnable { render() }

    private val lensH get() = (sizePx * ASPECT).toInt()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startAsForeground()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        zoom = prefs.getFloat("zoom", 2f)
        sizePx = dp(prefs.getInt("size", 220))
        posX = dp(80); posY = dp(80)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            // Android 14+: callback must be registered before createVirtualDisplay.
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, main)
        }
        thread = HandlerThread("capture").also { it.start() }
        capHandler = Handler(thread!!.looper)
        setupThermal()
        startCapture()
        buildLens()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cs", "Magnifier", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, MagnifierService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "cs")
            .setSmallIcon(R.drawable.ic_stat_lens)
            .setContentTitle("ClearSight Magnifier is running")
            .addAction(0, "Close", stop).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun startCapture() {
        val p = projection ?: return
        val m = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(m)
        screenW = m.widthPixels; screenH = m.heightPixels; dpi = m.densityDpi
        // maxImages=3: we keep the latest frame open so the lens can re-crop it when moved.
        val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ onFrame(it) }, capHandler)
        capHandler?.post { try { lastImage?.close() } catch (_: Exception) {}; lastImage = null; bmp = null }
        val old = reader; reader = r
        if (vd == null) vd = p.createVirtualDisplay(
            "clearsight", screenW, screenH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        ) else { vd!!.resize(screenW, screenH, dpi); vd!!.surface = r.surface }
        old?.close()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (projection != null) { startCapture(); moveTo(posX, posY) }
    }

    // ---- capture thread ----
    private fun onFrame(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try { lastImage?.close() } catch (_: Exception) {}
        lastImage = img
        if (!lensShown) return
        val h = capHandler ?: return
        if (SystemClock.uptimeMillis() - lastFrame < minIntervalMs) { // adaptive cap (slows down when phone is hot)
            h.removeCallbacks(renderRun); h.postDelayed(renderRun, minIntervalMs)
        } else render()
    }

    /** Region shown by the lens: just ABOVE it (or below if no room), so the capture never contains the lens itself. */
    private fun region(): Rect {
        val sw = (sizePx / zoom).toInt().coerceAtLeast(8)
        val sh = (lensH / zoom).toInt().coerceAtLeast(8)
        val gap = dp(6)
        val cx = posX + sizePx / 2
        var top = posY - gap - sh
        if (top < 0) top = posY + lensH + gap
        val left = (cx - sw / 2).coerceIn(0, (screenW - sw).coerceAtLeast(0))
        top = top.coerceIn(0, (screenH - sh - 2).coerceAtLeast(0))
        return Rect(left, top, left + sw, top + sh)
    }

    /** Copies ONLY the needed rows of the latest frame (not the whole screen). */
    private fun render() {
        val img = lastImage ?: return
        val l = lens ?: return
        if (!lensShown) return
        try {
            val r = region()
            val rows = r.height() + 1
            val pl = img.planes[0]
            val rowPx = pl.rowStride / pl.pixelStride
            var b = bmp
            if (b == null || b.width != rowPx || b.height != rows) {
                b = Bitmap.createBitmap(rowPx, rows, Bitmap.Config.ARGB_8888); bmp = b
            }
            val buf = pl.buffer
            buf.position(r.top * pl.rowStride)
            synchronized(l.lock) {
                b.copyPixelsFromBuffer(buf)
                l.frame = b
                l.src.set(r.left, 0, r.right, r.height())
            }
            lastFrame = SystemClock.uptimeMillis()
            l.postInvalidate()
        } catch (e: RuntimeException) {
            // skip a bad frame
        }
    }

    // ---- overlay ----
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun buildLens() {
        val l = LensView(this); lens = l
        l.setSharpen(prefs.getBoolean("sharp", true))
        val f = FrameView(this); srcFrame = f
        srcFrameLp = params(10, 10).also { it.flags = it.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE }
        wm.addView(f, srcFrameLp)
        lensLp = params(sizePx, lensH).apply { x = posX; y = posY }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var dragging = false
        val longPress = Runnable { if (!dragging) togglePanel() }
        l.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = posX; sy = posY; dragging = false
                    main.postDelayed(longPress, 500)
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (!dragging && (Math.abs(mx) > slop || Math.abs(my) > slop)) {
                        dragging = true; main.removeCallbacks(longPress); hidePanel()
                    }
                    if (dragging) moveTo(sx + mx.toInt(), sy + my.toInt())
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longPress)
            }
            true
        }
        wm.addView(l, lensLp)
        refresh()
    }

    private fun moveTo(x: Int, y: Int) {
        posX = x.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
        posY = y.coerceIn(0, (screenH - lensH).coerceAtLeast(0))
        lensLp.x = posX; lensLp.y = posY
        lens?.let { wm.updateViewLayout(it, lensLp) }
        refresh()
    }

    private fun refresh() {
        lens?.invalidate()
        positionFrame()
        zoomLabel?.text = "${zoom}x"
        if (panelShown) positionPanel()
        capHandler?.post(renderRun)
    }

    // ---- controls ----
    private fun togglePanel() { if (panelShown) hidePanel() else showPanel() }

    private fun showPanel() {
        if (panel == null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { setColor(0xE61B1D24.toInt()); cornerRadius = dp(20).toFloat() }
            }
            fun btn(t: String, f: () -> Unit) = TextView(this).apply {
                text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0); setOnClickListener { f() }
            }
            zoomLabel = TextView(this).apply { setTextColor(0xFF7FB0FF.toInt()); textSize = 13f; text = "${zoom}x" }
            listOf(
                btn("−") { stepZoom(-1) }, zoomLabel!!, btn("+") { stepZoom(1) },
                btn("Size−") { stepSize(-20) }, btn("Size+") { stepSize(20) },
                btn("Hide") { hideLens() }, btn("✕") { stopSelf() }
            ).forEach { row.addView(it, LinearLayout.LayoutParams(-2, dp(40))) }
            panel = row
        }
        wm.addView(panel, params(-2, dp(40)).also { it.x = posX; it.y = posY })
        panelShown = true; positionPanel()
    }

    private fun hidePanel() {
        if (panelShown) { try { wm.removeView(panel) } catch (_: Exception) {}; panelShown = false }
    }

    private fun positionPanel() {
        val p = panel ?: return
        val lp = p.layoutParams as WindowManager.LayoutParams
        val below = posY + lensH + dp(8)
        lp.x = posX; lp.y = if (below + dp(40) > screenH) posY - dp(48) else below
        wm.updateViewLayout(p, lp)
    }

    private fun stepZoom(d: Int) {
        val i = (zooms.indexOf(zoom).coerceAtLeast(0) + d).coerceIn(0, zooms.lastIndex)
        zoom = zooms[i]; prefs.edit().putFloat("zoom", zoom).apply(); refresh()
    }

    private fun stepSize(dDp: Int) {
        val dpNow = Math.round(sizePx / resources.displayMetrics.density)
        val n = (dpNow + dDp).coerceIn(100, 400)
        sizePx = dp(n); prefs.edit().putInt("size", n).apply()
        lensLp.width = sizePx; lensLp.height = lensH
        moveTo(posX, posY)
    }

    private fun hideLens() {
        hidePanel(); lensShown = false; lens?.visibility = View.GONE; srcFrame?.visibility = View.GONE
        val d = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x663D7BFF) }
            setOnClickListener {
                try { wm.removeView(this) } catch (_: Exception) {}
                dot = null; lens?.visibility = View.VISIBLE; srcFrame?.visibility = View.VISIBLE; lensShown = true; refresh()
            }
        }
        dot = d
        wm.addView(d, params(dp(40), dp(40)).also { it.x = posX; it.y = posY })
    }

    /** Outline around the exact area being magnified. */
    private fun positionFrame() {
        val f = srcFrame ?: return
        val r = region(); val b = dp(2)
        srcFrameLp.x = r.left - b; srcFrameLp.y = r.top - b
        srcFrameLp.width = r.width() + 2 * b; srcFrameLp.height = r.height() + 2 * b
        try { wm.updateViewLayout(f, srcFrameLp) } catch (_: Exception) {}
    }

    /** Protects the phone: slow down when warm, stop when critical. */
    private fun setupThermal() {
        if (Build.VERSION.SDK_INT < 29) return
        val pm = getSystemService(PowerManager::class.java)
        val l = PowerManager.OnThermalStatusChangedListener { s -> onThermal(s) }
        thermalListener = l
        pm.addThermalStatusListener(Executor { r -> main.post(r) }, l)
        onThermal(pm.currentThermalStatus)
    }

    private fun onThermal(s: Int) {
        minIntervalMs = when { s <= 1 -> 8L; s == 2 -> 33L; else -> 100L }
        if (s >= 4) {
            Toast.makeText(this, "Mainit ang phone. Itinigil ang magnifier.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        capHandler?.removeCallbacksAndMessages(null)
        hidePanel()
        listOf(lens, dot, srcFrame).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        if (Build.VERSION.SDK_INT >= 29) thermalListener?.let {
            try { getSystemService(PowerManager::class.java).removeThermalStatusListener(it) } catch (_: Exception) {}
        }
        vd?.release(); reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}

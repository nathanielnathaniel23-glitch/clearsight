package com.clearsight.magnifier

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.view.View

/** Rounded-rectangle lens: draws `src` region of the captured frame scaled to fill the view. */
class LensView(ctx: Context) : View(ctx) {
    val lock = Any()
    var frame: Bitmap? = null
    val src = Rect()
    private val dst = RectF()
    private val clip = Path()
    private val density = ctx.resources.displayMetrics.density
    private val bg = Paint().apply { color = 0xFF111111.toInt() }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val stroke = 1.5f * density
    private val radius = 8f * density
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; color = 0xB3FFFFFF.toInt()
    }

    /** GPU sharpen (Android 13+). Makes edges crisper; does not add real detail. */
    fun setSharpen(on: Boolean) {
        if (Build.VERSION.SDK_INT < 33) return
        try {
            if (on) {
                val s = RuntimeShader(SHARPEN)
                s.setFloatUniform("amount", 0.5f)
                setRenderEffect(RenderEffect.createRuntimeShaderEffect(s, "content"))
            } else setRenderEffect(null)
        } catch (e: Throwable) {
            setRenderEffect(null)
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        clip.reset(); clip.addRoundRect(stroke, stroke, w - stroke, h - stroke, radius, radius, Path.Direction.CW)
        c.save(); c.clipPath(clip)
        dst.set(0f, 0f, w, h)
        synchronized(lock) {
            val f = frame
            if (f == null) c.drawPaint(bg) else c.drawBitmap(f, src, dst, bmpPaint)
        }
        c.restore()
        c.drawRoundRect(stroke / 2, stroke / 2, w - stroke / 2, h - stroke / 2, radius, radius, border)
    }

    companion object {
        private const val SHARPEN = """
uniform shader content;
uniform float amount;
half4 main(float2 p) {
    half4 c = content.eval(p);
    if (c.a < 0.5) return c;
    half4 n = content.eval(p + float2(1.0, 0.0)) + content.eval(p - float2(1.0, 0.0))
            + content.eval(p + float2(0.0, 1.0)) + content.eval(p - float2(0.0, 1.0));
    half a = half(amount);
    half4 o = c + a * (half(4.0) * c - n);
    return half4(clamp(o.rgb, half3(0.0), half3(1.0)), c.a);
}
"""
    }
}

/** Thin outline marking EXACTLY which screen area the lens is magnifying. Touch-through. */
class FrameView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = 0xCC3D7BFF.toInt()
    }
    override fun onDraw(c: Canvas) {
        val h = p.strokeWidth / 2
        c.drawRect(h, h, width - h, height - h, p)
    }
}

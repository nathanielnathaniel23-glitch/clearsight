package com.clearsight.magnifier

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class MagnifierService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var bmp: Bitmap? = null
    private var lens: LensView? = null
    private var panel: View? = null
    private var dot: View? = null
    private var zoomLabel: TextView? = null
    private lateinit var lensLp: WindowManager.LayoutParams
    private var panelShown = false
    private var screenW = 0; private var screenH = 0; private var dpi = 0
    private var lastFrame = 0L
    @Volatile private var zoom = 2f
    @Volatile private var sizePx = 0
    @Volatile private var posX = 0
    @Volatile private var posY = 0
    @Volatile private var lensShown = true
    private val zooms = listOf(1.5f, 2.0f, 2.5f, 3.0f)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        startAsForeground()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java) else intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("prefs", MODE_PRIVATE)
        zoom = prefs.getFloat("zoom", 2f)
        sizePx = dp(prefs.getInt("size", 160))
        posX = dp(80); posY = dp(80)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            // Android 14+: callback must be registered before createVirtualDisplay.
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, main)
        }
        thread = HandlerThread("capture").also { it.start() }
        startCapture()
        buildLens()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cs", "Magnifier", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, MagnifierService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        @Suppress("DEPRECATION")
        val n = Notification.Builder(this, "cs")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("ClearSight Magnifier is running")
            .addAction(0, "Close", stop).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    @Suppress("DEPRECATION")
    private fun startCapture() {
        val p = projection ?: return
        val m = DisplayMetrics(); wm.defaultDisplay.getRealMetrics(m)
        screenW = m.widthPixels; screenH = m.heightPixels; dpi = m.densityDpi
        val r = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ onFrame(it) }, Handler(thread!!.looper))
        val old = reader; reader = r; bmp = null
        if (vd == null) vd = p.createVirtualDisplay(
            "clearsight", screenW, screenH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        ) else { vd!!.resize(screenW, screenH, dpi); vd!!.surface = r.surface }
        old?.close()
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (projection != null) { startCapture(); moveTo(posX, posY) }
    }

    private fun onFrame(rd: ImageReader) {
        val img = try { rd.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            val now = SystemClock.uptimeMillis()
            val l = lens ?: return
            if (!lensShown || now - lastFrame < 33) return // ~30 fps cap
            lastFrame = now
            val pl = img.planes[0]
            val rowPx = pl.rowStride / pl.pixelStride
            var b = bmp
            if (b == null || b.width != rowPx || b.height != img.height) {
                b = Bitmap.createBitmap(rowPx, img.height, Bitmap.Config.ARGB_8888); bmp = b
            }
            synchronized(l.lock) {
                pl.buffer.rewind(); b.copyPixelsFromBuffer(pl.buffer)
                l.frame = b; computeSrc(l)
            }
            l.postInvalidate()
        } catch (e: RuntimeException) {
            // skip a bad frame
        } finally { img.close() }
    }

    /**
     * Source region sits just ABOVE the lens (or below if no room), so the capture never
     * includes the lens itself (avoids feedback loop). It is NOT directly under the lens.
     */
    private fun computeSrc(l: LensView) {
        val sw = (sizePx / zoom).toInt().coerceAtLeast(8)
        val gap = dp(8)
        val cx = posX + sizePx / 2
        var top = posY - gap - sw
        if (top < 0) top = posY + sizePx + gap
        val left = (cx - sw / 2).coerceIn(0, (screenW - sw).coerceAtLeast(0))
        top = top.coerceIn(0, (screenH - sw).coerceAtLeast(0))
        l.src.set(left, top, left + sw, top + sw)
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun buildLens() {
        val l = LensView(this); lens = l
        lensLp = params(sizePx, sizePx).apply { x = posX; y = posY }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var dragging = false
        val longPress = Runnable { if (!dragging) togglePanel() }
        l.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = posX; sy = posY; dragging = false
                    main.postDelayed(longPress, 500)
                }
                MotionEvent.ACTION_MOVE -> {
                    val mx = e.rawX - dx; val my = e.rawY - dy
                    if (!dragging && (Math.abs(mx) > slop || Math.abs(my) > slop)) {
                        dragging = true; main.removeCallbacks(longPress); hidePanel()
                    }
                    if (dragging) moveTo(sx + mx.toInt(), sy + my.toInt())
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> main.removeCallbacks(longPress)
            }
            true
        }
        wm.addView(l, lensLp)
        refresh()
    }

    private fun moveTo(x: Int, y: Int) {
        posX = x.coerceIn(0, (screenW - sizePx).coerceAtLeast(0))
        posY = y.coerceIn(0, (screenH - sizePx).coerceAtLeast(0))
        lensLp.x = posX; lensLp.y = posY
        lens?.let { wm.updateViewLayout(it, lensLp) }
        refresh()
    }

    private fun refresh() {
        lens?.let { synchronized(it.lock) { computeSrc(it) }; it.invalidate() }
        zoomLabel?.text = "${zoom}x"
        if (panelShown) positionPanel()
    }

    // ---- controls ----
    private fun togglePanel() { if (panelShown) hidePanel() else showPanel() }

    private fun showPanel() {
        if (panel == null) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { setColor(0xE61B1D24.toInt()); cornerRadius = dp(20).toFloat() }
            }
            fun btn(t: String, f: () -> Unit) = TextView(this).apply {
                text = t; setTextColor(Color.WHITE); textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0); setOnClickListener { f() }
            }
            zoomLabel = TextView(this).apply { setTextColor(0xFF7FB0FF.toInt()); textSize = 13f; text = "${zoom}x" }
            listOf(
                btn("−") { stepZoom(-1) }, zoomLabel!!, btn("+") { stepZoom(1) },
                btn("Size−") { stepSize(-20) }, btn("Size+") { stepSize(20) },
                btn("Hide") { hideLens() }, btn("✕") { stopSelf() }
            ).forEach { row.addView(it, LinearLayout.LayoutParams(-2, dp(40))) }
            panel = row
        }
        wm.addView(panel, params(-2, dp(40)).also { it.x = posX; it.y = posY })
        panelShown = true; positionPanel()
    }

    private fun hidePanel() {
        if (panelShown) { try { wm.removeView(panel) } catch (_: Exception) {}; panelShown = false }
    }

    private fun positionPanel() {
        val p = panel ?: return
        val lp = p.layoutParams as WindowManager.LayoutParams
        val below = posY + sizePx + dp(8)
        lp.x = posX; lp.y = if (below + dp(40) > screenH) posY - dp(48) else below
        wm.updateViewLayout(p, lp)
    }

    private fun stepZoom(d: Int) {
        val i = (zooms.indexOf(zoom).coerceAtLeast(0) + d).coerceIn(0, zooms.lastIndex)
        zoom = zooms[i]; prefs.edit().putFloat("zoom", zoom).apply(); refresh()
    }

    private fun stepSize(dDp: Int) {
        val dpNow = Math.round(sizePx / resources.displayMetrics.density)
        val n = (dpNow + dDp).coerceIn(80, 280)
        sizePx = dp(n); prefs.edit().putInt("size", n).apply()
        lensLp.width = sizePx; lensLp.height = sizePx
        moveTo(posX, posY)
    }

    private fun hideLens() {
        hidePanel(); lensShown = false; lens?.visibility = View.GONE
        val d = View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x663D7BFF) }
            setOnClickListener {
                try { wm.removeView(this) } catch (_: Exception) {}
                dot = null; lens?.visibility = View.VISIBLE; lensShown = true; refresh()
            }
        }
        dot = d
        wm.addView(d, params(dp(40), dp(40)).also { it.x = posX; it.y = posY })
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        hidePanel()
        listOf(lens, dot).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Exception) {} } }
        vd?.release(); reader?.close()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}

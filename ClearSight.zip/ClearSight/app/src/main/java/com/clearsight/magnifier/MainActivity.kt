package com.clearsight.magnifier

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }
    private val zooms = listOf(1.5f, 2.0f, 2.5f, 3.0f)
    private val sizes = listOf(120, 160, 200) // dp: Small, Medium, Large

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0E0F13.toInt()); setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(text("ClearSight Magnifier", 26f, Color.WHITE, true))
        root.addView(text("Floating lens para sa mas malinaw na pagtingin.", 14f, 0xFF9AA0AE.toInt(), false))
        status = text("", 14f, 0xFFCCD0DA.toInt(), false).apply { setPadding(0, dp(20), 0, dp(8)) }
        root.addView(status)

        root.addView(label("Magnification"))
        val zi = zooms.indexOf(prefs.getFloat("zoom", 2f)).coerceAtLeast(0)
        root.addView(chips(zooms.map { "${it}x" }, zi) { prefs.edit().putFloat("zoom", zooms[it]).apply() })

        root.addView(label("Lens size"))
        val si = sizes.indexOf(prefs.getInt("size", 160)).coerceAtLeast(0)
        root.addView(chips(listOf("Small", "Medium", "Large"), si) { prefs.edit().putInt("size", sizes[it]).apply() })

        root.addView(Button(this).apply {
            text = "Start Magnifier"; isAllCaps = false; setTextColor(Color.WHITE)
            background = round(0xFF3D7BFF.toInt())
            setOnClickListener { start() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(32) })

        root.addView(text(
            "Tip: sa screen-share prompt, piliin ang \"Entire screen\". " +
                "Long-press ang lens para lumabas ang controls. Naka-offline ang app; walang data na kinokolekta.",
            12f, 0xFF7B8190.toInt(), false
        ).apply { setPadding(0, dp(20), 0, 0) })
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        val ov = if (Settings.canDrawOverlays(this)) "Granted ✓" else "Kailangan ✗"
        status.text = "Overlay permission: $ov\nScreen capture: hihingin tuwing Start"
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, MagnifierService::class.java)
                    .putExtra(MagnifierService.EXTRA_CODE, res)
                    .putExtra(MagnifierService.EXTRA_DATA, data)
            )
            moveTaskToBack(true)
        }
    }

    private fun round(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(12).toFloat() }
    private fun text(t: String, sp: Float, c: Int, bold: Boolean) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(c); if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun label(t: String) = text(t, 13f, 0xFF9AA0AE.toInt(), false).apply { setPadding(0, dp(20), 0, dp(8)) }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = labels.map { Button(this).apply { text = it; isAllCaps = false; setTextColor(Color.WHITE) } }
        fun paint(sel: Int) = buttons.forEachIndexed { i, bt ->
            bt.background = round(if (i == sel) 0xFF3D7BFF.toInt() else 0xFF2A2D36.toInt())
        }
        buttons.forEachIndexed { i, bt ->
            bt.setOnClickListener { paint(i); onPick(i) }
            row.addView(bt, LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        paint(selected)
        row.gravity = Gravity.CENTER
        return row
    }
}

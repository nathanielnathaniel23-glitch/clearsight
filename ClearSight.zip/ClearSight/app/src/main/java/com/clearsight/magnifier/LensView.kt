package com.clearsight.magnifier

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.View

/** Circular lens: draws `src` region of the captured frame scaled to fill the circle. */
class LensView(ctx: Context) : View(ctx) {
    val lock = Any()
    var frame: Bitmap? = null
    val src = Rect()
    private val dst = RectF()
    private val clip = Path()
    private val bg = Paint().apply { color = 0xFF111111.toInt() }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val stroke = 1.5f * ctx.resources.displayMetrics.density
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; color = 0xB3FFFFFF.toInt()
    }

    override fun onDraw(c: Canvas) {
        val r = width / 2f
        clip.reset(); clip.addCircle(r, r, r - stroke, Path.Direction.CW)
        c.save(); c.clipPath(clip)
        dst.set(0f, 0f, width.toFloat(), height.toFloat())
        synchronized(lock) {
            val f = frame
            if (f == null) c.drawPaint(bg) else c.drawBitmap(f, src, dst, bmpPaint)
        }
        c.restore()
        c.drawCircle(r, r, r - stroke / 2, border)
    }
}
